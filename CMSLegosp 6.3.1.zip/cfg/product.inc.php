<?php
	define('CONF_SHOW_ADD2CART', '1');
	define('CONF_SHOW_ADD2CART_INSTOCK', '0');
	define('CONF_SHOW_PRODUCT_INSTOCK', '1');
	define('CONF_SHOW_PRODUCT_VARIANTS_INSTOCK', '0');
	define('CONF_REVIEW_WRITE', '1');
	define('CONF_REVIEW_LINK', '0');
	define('CONF_REVIEW_MODER', '0');
	define('CONF_FLOAT_QUANTITY', '1');
	define('CONF_PRESENT_SELECT', '0');
	define('CONF_SORT_CATEGORY', 'categoryID');
	define('CONF_SORT_CATEGORY_BY', 'ASC');
	define('CONF_SORT_PRODUCT', 'productID');
	define('CONF_SORT_PRODUCT_BY', 'ASC');
?>