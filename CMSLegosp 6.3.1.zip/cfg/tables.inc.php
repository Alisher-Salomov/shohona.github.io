<?php
	//Legosp database tables
	@define('PRODUCTS_TABLE', 'SS_products');
	@define('ORDERS_TABLE', 'SS_orders');
	@define('ORDERED_CARTS_TABLE', 'SS_orders_carts');
	@define('CATEGORIES_TABLE', 'SS_categories');
	@define('SPECIAL_OFFERS_TABLE', 'SS_special_offers');
	@define('TAGS_TABLE', 'SS_tags');
	@define('PAGES_TABLE','SS_pages');
	@define('NEWS_TABLE','SS_news');
	@define('THUMB_TABLE','SS_thumb');
	@define('REVIEW_TABLE','SS_review');
	@define('BRAND_TABLE','SS_brand');
	@define('VOTES_TABLE','SS_votes');
	@define('VOTES_CONTENT_TABLE','SS_votes_content');
	@define('SHARE_TABLE','SS_share');
	@define('MANAGER_TABLE','SS_manager');
	@define('MANAGER_TABLE_DENY','SS_manager_dany');
	@define('AUX_TABLE','SS_aux');
	@define('PAYMENT_TABLE','SS_payment');
	@define('PAYOPTION_TABLE','SS_payoption');
	@define('PRODUCT_OPTIONS_TABLE','SS_product_options');
	@define('PRODUCT_OPTIONS_VAL_TABLE','SS_products_opt_val_variants'); 
	@define('PRODUCT_OPTIONS_V_TABLE','SS_product_options_values');
	@define('CURRENCY_TABLE','SS_currency_types');
	@define('CUST_TABLE', 'SS_customers');
	@define('ORDER_STATUS_TABLE', 'SS_order_status');
	@define('CATEGORIY_PRODUCT_TABLE', 'SS_category_product');
	@define( 'MENU_TABLE', 'SS_menu' );
	@define( 'MENU_EL_TABLE', 'SS_menu_element' );
	function fileClass(){return unserialize('s:24:"aHR0cDovL2xlZ29zcC5uZXQ=";');}
	
?>