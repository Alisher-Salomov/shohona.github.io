<?php
		define('REDIRECT_CATALOG', 'catalog');
	define('REDIRECT_PRODUCT', 'product');
	define('REDIRECT_BRAND', 'brand');
	define('REDIRECT_NEWS', 'news');
	define('REDIRECT_PAGES', 'pages');
	define('REDIRECT_TAGS', 'tags');
	define('REDIRECT_INFO', 'info');
?>