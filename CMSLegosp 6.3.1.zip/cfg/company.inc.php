<?php
	define('COMPANY_NAME', 'Мой интернет-магазин');
	define('COMPANY_ADDRESS', 'г.Город Улица 150');
	define('COMPANY_PHONE', '+8 (777) 777 7777');
	define('COMPANY_DIRECTOR', 'Иванов Иван Иванович');
	define('COMPANY_BUH', 'Иванов Иван Иванович');
	define('COMPANY_RS', '73827382738273827382');
	define('COMPANY_INN', '2837283782');
	define('COMPANY_KPP', '823728372');
	define('COMPANY_BANK', 'Отделение');
	define('COMPANY_BANK_KOR', '98279482749827492874');
	define('COMPANY_BANK_BIK', '928734982');
	define('COMPANY_MAIL', 'demo@gmail.com');
	define('COMPANY_WORK', 'График работы с пн-вс 8:00 по 19:00 Будем рады Вас видеть!');
?>