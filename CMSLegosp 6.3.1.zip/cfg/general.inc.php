<?php
	define('CONF_SHOP_NAME', 'Powered by Legosp');
	define('CONF_SHOP_DESCRIPTION', 'Powered by Legosp, Powered by Legosp');
	define('CONF_SHOP_KEYWORDS', 'Powered by Legosp, Powered by Legosp');
	define('CONF_SHOP_URL', '');
	define('CONF_GENERAL_EMAIL', 'admin@gmail.com');
	define('CONF_ORDERS_EMAIL', 'admin@gmail.com');
	define('CONF_ADMIN_FILE', 'admin.php');
	define('CONF_ADMIN_FILE_ACCESS', 'access_admin.php');
	define('CONF_SMTP', '0');
	define('CONF_SMTP_HOST', '127.0.0.1');
	define('CONF_SMTP_Port', '25');  
	define('CONF_SMTP_User', '');
	define('CONF_SMTP_Pass', '');
	define('CONF_CURRENCY_AUTO', '0');
	define('CONF_CURRENCY_ID', 1);
	define('CONF_CHPU', 1); 
?>